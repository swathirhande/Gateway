import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import com.example.plugincall.AbstractPlugin;
import com.example.plugincall.PluginLoader;
import com.example.plugincall.PluginLoader.PluginData;

public class Main {
	public static void main(String[] args) {
		final File plugin_list = new File("C:\\Users\\RajendraPrasadH\\eclipse-workspace\\PluginApp\\src\\config.cfg");

		try {
			PluginLoader.parseConfig(plugin_list, null);
			System.out.println("Success of calling PluginLoader.parseConfig");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		final HashMap<String, PluginData> plugin_datas = PluginLoader.getPlugins();
		System.out.println("plugin_datas contain" + plugin_datas);
		final AbstractPlugin[] plugins = new AbstractPlugin[plugin_datas.size()];
		System.out.println("The plugins are " + plugins);
		try {
			int i = 0;
			for (String key : plugin_datas.keySet()) {
				plugins[i++] = PluginLoader.newInstance(plugin_datas.get(key));
			}
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}

		for (AbstractPlugin plugin : plugins) {
			plugin.start();
		}

		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		for (AbstractPlugin plugin : plugins) {
			plugin.interrupt();
			try {
				plugin.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			plugin.close();

		}

	}

}
