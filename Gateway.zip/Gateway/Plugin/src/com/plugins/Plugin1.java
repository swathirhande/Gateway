package com.plugins;

import com.example.plugincall.AbstractPlugin;

public class Plugin1 extends AbstractPlugin {
	private int i = 0;

	@Override
	public void run() {
		System.out.println("Plugin1 is running");
		while (true) {
			try {
				Thread.sleep(500);
			} catch (Exception e) {

				break;
			}
			i++;
		}
	}

	@Override
	public void close() {
		System.out.println("Plugin1 stooped");
		System.out.println("Value of i is" + i);
	}
}
