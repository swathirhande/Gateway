package com.plugins1;

public class Plugin2 {

}
